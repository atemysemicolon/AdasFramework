AdasFramework
=============

A complete dataset handler + pipeline Manager
