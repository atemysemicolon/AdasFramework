#ifndef CVCCORE_H
#define CVCCORE_H
#include "datamodules.h"
#include "PipeCore.h"
#include "../DatasetReader/datasetReader.h"
#include "../AnnotationManager/annotationManager.h"
#endif // CVCCORE_H
