#include <iostream>
#include <opencv2/opencv.hpp>
#include "annotationManager.h"


int main()
{
    std::cout << "Hello World!" << std::endl;
    std::shared_ptr<cvc::ClassData> obj (new cvc::KittiClassData);
    std::shared_ptr<cvc::cData> data(new cvc::cData);

    std::shared_ptr<cvc::KittiDataset> kitti(new cvc::KittiDataset);
    std::shared_ptr<cvc::cDataset> ds(new cvc::cDataset);
    ds->loadDataset(kitti, cvc::DatasetTypes::TRAIN);


    cv::Mat annT= cv::imread("/home/prassanna/Development/DataTest/sample_predicted_gt.png");
    annT.convertTo(data->annotation_orig, CV_8U);
    cvc::annotatonManager ann;
    ann.init(obj, ds);
    //ann.process(data);

    //cv::Mat indexIm = ann.class_ptr->loadImagetoIndices(data->annotation_orig);
    //std::cout<<indexIm<<std::endl;
    cv::Mat translated = ann.class_ptr->loadIndicestoImage(data->annotation_orig);
    cv::imshow("bla",translated);
    //std::cout<<data->annotation_indexed;
    //std::cout<<newObj.labels_colours_image_translated;

    cv::waitKey(0);

    return 0;
}

