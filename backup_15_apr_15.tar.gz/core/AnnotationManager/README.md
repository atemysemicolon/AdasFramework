AnnotationManager
=================

For image datasets, to convert Annotations(labels) into indices


HOW TO USE
===============
1.Derive ClassData and put your dataset details there
2.If you want to map some label indices to another label, you can, by modifying map



TODO
============
1. Speed up with TBB
2. Provide cross platform make with cmake
