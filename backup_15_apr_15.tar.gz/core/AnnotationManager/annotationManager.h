#ifndef ANNOTATIONMANAGER_H
#define ANNOTATIONMANAGER_H
#include <opencv2/core/mat.hpp>
//#include <boost/algorithm/string.hpp>
#include <memory>
#include "../Pipeline/cvccore.h"
namespace cvc
{
using namespace std;

class ClassData
{


public:
    ClassData()
    {
        build_default_map();
    }
    std::string dataset_name;
   std::vector<cv::Vec3b> label_colours;
   std::vector<std::string> label_names;
   cv::Mat_<uchar> labels_indices_image;
   cv::Mat labels_colours_image;
   cv::Mat labels_colours_image_translated;
   std::vector<int> map_indices;

    void build_default_map()
    {
        map_indices.clear();
        for(int i=0;i<std::min(this->label_names.size(), this->label_colours.size());i++)
            map_indices.push_back(i);
    }


    void build_unique_map(std::vector<cv::Vec3b> &colours_temp, std::vector<std::string> &names_temp)
    {

        std::vector<int> unique_indices;

        for (int i=0;i<map_indices.size();i++)
        {
            bool copyFlag=true;
            int map_value=map_indices[i];

            for(int j=0;j<i;j++)
                if(map_value==map_indices[j])
                {
                    copyFlag =false;
                    break;
                }

            if(copyFlag)
            {
                unique_indices.push_back(map_value);
            }
        }

        for(int i=0;i<unique_indices.size();i++)
        {
            colours_temp.push_back(this->label_colours[unique_indices[i]]);
            names_temp.push_back(this->label_names[unique_indices[i]]);
        }



    }

   int find_label_index(cv::Vec3b colour)
   {
       int index=-1;
       for(std::vector<cv::Vec3b>::iterator it = label_colours.begin(); it != label_colours.end(); ++it)
       {
           if(*it == colour)
           {
                index = std::distance(label_colours.begin(), it);
                break;
           }
       }

       if(index>=0) return index;
       else return -1;
   }
   int find_label_index(std::string label_name)
   {
       int index=-1;
       for(std::vector<std::string>::iterator it = label_names.begin(); it != label_names.end(); ++it)
       {
           if(label_name.compare(*it)==0)
           {
                index = std::distance(label_names.begin(), it);
                break;
           }
       }

       if(index>=0) return index;
       else return -1;

   }

   std::string find_label_name(int label_index)
   {
       return label_names[label_index];

   }

   std::string find_label_name(cv::Vec3b colour)
   {
       int index=-1;
       for(std::vector<cv::Vec3b>::iterator it = label_colours.begin(); it != label_colours.end(); ++it)
       {
           if(*it == colour)
           {
                index = std::distance(label_colours.begin(), it);
                break;
           }
       }

       if(index>=0) return label_names[index];
       else return "null";
   }
   cv::Vec3b find_label_colour (int label_index)
   {
       return label_colours[label_index];

   }
   cv::Vec3b find_label_colour (std::string label_name)
   {
       int index=-1;
       for(std::vector<std::string>::iterator it = label_names.begin(); it != label_names.end(); ++it)
       {
           if(label_name.compare(*it)==0)
           {
                index = std::distance(label_names.begin(), it);
                break;
           }
       }

       if(index>=0) return label_colours[index];
       else return cv::Vec3b(1,1,1);
   }

   cv::Mat loadImagetoIndices(cv::Mat &label_image)
   {
       cv::Mat_<cv::Vec3b> &templatedImage = (cv::Mat_<cv::Vec3b> &)label_image;
       cv::Mat_<uchar> indexImage(label_image.rows, label_image.cols);
       for(int x=0;x<templatedImage.cols;x++)
           for(int y=0;y<templatedImage.rows;y++)
           {
               uchar index = find_label_index(templatedImage(y,x));

               if(index >=0 )
                   indexImage(y,x) = map_indices[index];

           }

       //this->labels_indices_image = indexImage.clone();

       return indexImage;

   }

   cv::Mat loadIndicestoImage(cv::Mat &index_image)
   {
       cv::Mat_<uchar> templatedImage = (cv::Mat_<uchar> &) index_image;
       cv::Mat_<cv::Vec3b> colorImage(templatedImage.rows, templatedImage.cols);
       for(int x=0;x<templatedImage.cols;x++)
           for(int y=0;y<templatedImage.rows;y++)
           {
               uchar index = templatedImage(y,x);

               if( (index >=0) && (index <this->label_colours.size()) )
                   colorImage(y,x) = label_colours[index];

           }

       this->labels_colours_image_translated = colorImage.clone();
       return colorImage;


   }

   void loadLabelMat(cv::Mat &input_labels_colours)
   {
        this->labels_colours_image = input_labels_colours.clone();
   }

};


class CamVidClassData : public ClassData
{
public:
    CamVidClassData() : ClassData()
    {



        label_names = {"Sky",
                       "Building",
                       "Road",
                       "Sidewalk",
                       "Fence",
                       "Vegetation",
                       "Pole",
                       "Car",
                       "Sign",
                       "Pedestrian",
                       "Cyclist",
                       "Void",

                       "Animal",
                       "Archway",
                       "Bridge",
                       "CartLuggagePram",
                       "Child",
                       "LaneMkgsDrive",
                       "LaneMkgsNonDrive",
                       "Misc_Text",

                       "Motorcyclee",
                       "OtherMoving",
                       "ParkingBlock",
                       "RoadShoulder",
                       "SUV",

                       "TrafficCone",
                       "TrafficLight",
                       "Train",
                       "Tree",
                       "Truck_bus",
                       "Tunnel",
                       "Wall"};

        label_colours = { cv::Vec3b(128,128,128),
                         cv::Vec3b(0,0,128),
                         cv::Vec3b(128,64,128),
                         cv::Vec3b(192,0,0),
                         cv::Vec3b(64,64,128),
                         cv::Vec3b(0,192,192),
                         cv::Vec3b(128,192,192),
                         cv::Vec3b(128,0,64),
                         cv::Vec3b(128,128,192),
                         cv::Vec3b(0,0,64),
                         cv::Vec3b(192,128,0),
                         cv::Vec3b(0,0,0),

                          cv::Vec3b(64,128,64),
                          cv::Vec3b(128,0,192),
                          cv::Vec3b(64,128,0),
                          cv::Vec3b(192,0,64),
                          cv::Vec3b(64,128,192),
                          cv::Vec3b(192,0,128),
                          cv::Vec3b(64,0,192),
                          cv::Vec3b(64,128,128),

                          cv::Vec3b(192,0,192),
                          cv::Vec3b(64,64,128),
                          cv::Vec3b(128,192,64),
                          cv::Vec3b(192,128,128),
                          cv::Vec3b(192,128,64),

                          cv::Vec3b(64,0,0),
                          cv::Vec3b(64,64,0),
                          cv::Vec3b(128,64,192),
                          cv::Vec3b(0,128,192),
                          cv::Vec3b(192,128,192),
                          cv::Vec3b(64,0,64),
                          cv::Vec3b(0,192,64)};


        dataset_name = "CamVid";
        build_default_map();
        this->map_indices={3,1,10,11,4,2,5,6,8,9,7,0,
                           0,0,0,0,9,11,11,0,
                           7,5,11,11,5,
                           0,5,0,2,5,0,0};

    }
};

class KittiClassData : public ClassData
{
public:
    KittiClassData() : ClassData()
    {
        label_colours = {cv::Vec3b(0,0,0), //Void
                         cv::Vec3b(0,0,128), //Building
                         cv::Vec3b(0,128,128), //Vegetation
                         cv::Vec3b(128,128,128), //Sky
                         cv::Vec3b(128,64,64),  //Fence
                         cv::Vec3b(128,192,192), //Pole
                         cv::Vec3b(128,0,64), //Car
                         cv::Vec3b(192,128,0), //cyclist
                         cv::Vec3b(192,128,128), //Sign
                         cv::Vec3b(64,64,0), //Pedestrian
                         cv::Vec3b(128,64,128), //Road
                         cv::Vec3b(192,0,0) //Sidewalk
                         };

        label_names = {"Void",
                       "Building",
                       "Vegetation",
                       "Sky",
                       "Fence",
                       "Pole",
                       "Car",
                       "Cyclist",
                       "Sign",
                       "Pedestrian",
                       "Road",
                       "Sidewalk"};

        dataset_name = "kitti";

        build_default_map(); //Always from larger to smaller
        //this->map_indices[4]=1;
        //this->map_indices[8]=6; //TO DO:To uniquely rebuild map and other vectors.

//        this->map_indices={0,
//                           1,
//                           2,
//                           3,
//                           1,
//                           11,
//                           11,
//                           7,
//                           11,
//                           11,
//                           7,
//                           11};
    }
};

class annotatonManager : public cPipeModule
{
public:
    std::shared_ptr<ClassData> class_ptr;
    void init(std::shared_ptr<ClassData> class_obj, std::shared_ptr<cvc::cDataset> dataset)
    {
        this->data_type=DATA_SINGLE;
        class_ptr = class_obj;
        this->initClassData(class_obj, dataset->class_data);
        this->pipe_name = "AnnotationManager";
    }
    bool initClassData(std::shared_ptr<ClassData> cl_data, classdataStruct &class_data)
        {
            std::vector<cv::Vec3b> colours;
            std::vector<std::string> names;
            cl_data->build_unique_map(colours, names);
            class_data.dataset = cl_data->dataset_name;
            class_data.class_names = names;
            class_data.class_colours = colours;
            class_data.number_of_classes = colours.size();
            class_data.class_map = cl_data->map_indices;
            class_data.exists=true;

        }

    void processData(std::shared_ptr<cData> data)
    {
        data->annotation_indexed=class_ptr->loadImagetoIndices(data->annotation_orig).clone();


    }
};

}
#endif // ANNOTATIONMANAGER_H
