DatasetReader
=============

A small project to iterate through a dataset, which is structured in different folders for images and annotations. Especially useful in Scene Segmentation datasets, example with Camvid

TODO:Test on windows
TODO:Shift to Cmake
