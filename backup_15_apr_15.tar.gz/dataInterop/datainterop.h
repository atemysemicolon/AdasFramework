#ifndef DATAINTEROP_H
#define DATAINTEROP_H

#include "datainterop_global.h"

class DATAINTEROPSHARED_EXPORT DataInterop
{

public:
    DataInterop();
};

#endif // DATAINTEROP_H
