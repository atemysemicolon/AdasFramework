#include "datainterop.h"


DataInterop::DataInterop()
{
}
