SuperpixelMap
=============

Calculate SLIC superpixels and their neighbours

Based on https://github.com/PSMM/SLIC-Superpixels
