//
//  main.cpp
//  SLICSuperpixel Superpixels
//
//  Created by Saburo Okita on 22/04/14.
//  Copyright (c) 2014 Saburo Okita. All rights reserved.
//

#include <iostream>
#include <opencv2/opencv.hpp>
#include <memory>
#include "csuperpixel.h"
using namespace std;
using namespace cv;

int main(int argc, const char * argv[]) {
    Mat image = imread( "/home/prassanna/Development/DataTest/Lenna.png" );
    Mat ann_image_t =  imread( "/home/prassanna/Development/DataTest/sample_gt.png" );
    Mat ann_img;
    ann_image_t.convertTo(ann_img, CV_8U);

    std::shared_ptr<cvc::cData> dt(new cvc::cData);
    dt->image = image.clone();
    dt->annotation_indexed=ann_img.clone();

    cvc::cSuperpixel sup;
    sup.init(400);
    sup.process(dt);

    image.release();
    ann_image_t.release();
    ann_img.release();





    return 0;
}
