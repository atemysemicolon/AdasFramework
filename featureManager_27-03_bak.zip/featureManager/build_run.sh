cd /home/prassanna/Development/workspace/builds/featureManager/
qmake /home/prassanna/Development/workspace/AdasFramework/featureManager/featureManager.pro
make -j6
./featureManager 
