#include <iostream>

#include <memory>
#include <map>
#include <opencv2/features2d/features2d.hpp>
#include "featuremanager.h"

int main()
{
    cv::Mat img = cv::imread("/home/prassanna/Development/DataTest/Lenna.png");
    cv::Mat img_segmented = cv::imread("/home/prassanna/Development/DataTest/Lenna_sup.png");
    cv::cvtColor(img_segmented, img_segmented, cv::COLOR_BGR2GRAY);
    std::shared_ptr<cvc::cData> dt(new cvc::cData);
    dt->image = img.clone();
    dt->superpixel_segments = img_segmented.clone();

    std::vector<cvc::FeatureList> feat_names;
    feat_names.push_back(cvc::FeatureList::SIFT);
    feat_names.push_back(cvc::FeatureList::COLOR);
    cvc::featureManager feats;
    feats.to_bow_descriptor=false;
    feats.initFeatures(feat_names);
    //feats.processData(dt);


    feats.calculateDescriptor(img, img_segmented);
    feats.descriptors_concatenated=feats.features_ptr[0]->descriptors;

    std::cout<<"("<<feats.descriptors_concatenated.rows<<","<<feats.descriptors_concatenated.cols<<")"<<std::endl;


    cvc::codifyFeatures codes;
    cv::Mat weights, bias;
    codes.aggregateDescriptors(feats.descriptors_concatenated);
    codes.calculateWeights(codes.descriptors_all,weights,bias);
    std::cout<<weights<<std::endl;
    std::cout<<bias<<std::endl;
//    codes.clusterEmAll();
    //cv::Mat bla = codes.normalToBowDescriptor(feats.descriptors_concatenated);


    return 0;
}

