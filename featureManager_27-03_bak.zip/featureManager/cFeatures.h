#ifndef CFEATURES_H
#define CFEATURES_H

#include <opencv2/opencv.hpp>

#define OPENCV3 0
#if OPENCV3
#include <opencv2/features2d.hpp>               //Opencv3
//#include <opencv2/xfeatures2d.hpp>              //Opencv3
#include <opencv2/xfeatures2d/nonfree.hpp>
#else
#include <opencv2/nonfree/nonfree.hpp>        //Opencv2
#include <opencv2/features2d/features2d.hpp>  //Opencv2
#endif

#include <tbb/tbb.h>
#include <LBP/lbp.hpp>
#include <LBP/histogram.hpp>



namespace cvc
{


class cFeatures
{
public:
    cv::Ptr<cv::FeatureDetector> detector;
    cv::Ptr<cv::DescriptorExtractor> extractor;
    cv::Mat descriptors;
    std::vector<int> descriptor_map; //Map from superpixels to descriptor rows
    std::vector<cv::KeyPoint> keypoints;
    int length;

    virtual void calculateKeypoints(const cv::Mat &img){}
    virtual void calculateDescriptors(const cv::Mat &img, const cv::Mat &segments){}
    virtual void loadDescriptorsFromFile(std::string file) {}

};



//Got to create it because useless Opencv3 does not have it
class denseFeatureDetector:public cv::FeatureDetector
{
public:

    int initXyStep;
    int initFeatureScale;

    denseFeatureDetector(int step, int scale)
    {
        initXyStep=step;
        initFeatureScale=scale;
    }

    void detect(cv::InputArray _image, std::vector<cv::KeyPoint>& keypoints, cv::InputArray mask=cv::noArray())
    {
        float curScale = static_cast<float>(initFeatureScale);

        cv::Mat image =_image.getMat();
        if(!keypoints.empty())
            keypoints.clear();


        for( int x = 0; x < image.cols; x += initXyStep)
        {
            for( int y = 0; y < image.rows; y += initXyStep)
            {
                keypoints.push_back( cv::KeyPoint(static_cast<float>(x), static_cast<float>(y), curScale) );
            }
        }




    }


};


class SiftDescriptor : public cFeatures
{
public:

    SiftDescriptor()
    {
#if OPENCV3
        detector  = cv::Ptr<cv::FeatureDetector>(new denseFeatureDetector); //Opencv3
        //extractor = cv::Ptr<cv::DescriptorExtractor>(new cv::xfeatures2d::SiftFeatureDetector);
        //extractor = cv::Ptr<cv::DescriptorExtractor>(new cv::xfeatures2d::SurfDescriptorExtractor);
        extractor = cv::xfeatures2d::SIFT::create();
#else
        detector = cv::Ptr<cv::FeatureDetector>(new cv::DenseFeatureDetector);
        extractor = cv::Ptr<cv::DescriptorExtractor>(new cv::SiftDescriptorExtractor); //Opencv2

#endif

    }
    ~SiftDescriptor()
    {
        detector.release();
        extractor.release();
    }

    void calculateKeypoints(const cv::Mat &img)
    {
        this->keypoints.clear();
        detector->detect(img, this->keypoints);
    }

    void calculateDescriptors(const cv::Mat &img, const cv::Mat &segments)
    {
        cv::Mat localImg;
        cv::cvtColor(img,localImg, cv::COLOR_BGR2GRAY);
        extractor->compute(localImg, this->keypoints,this->descriptors);
        this->length = this->descriptors.cols;
//        cv::xfeatures2d::SURF surf;
//        sift.detectAndCompute(localImg, cv::Mat(), this->keypoints, this->descriptors);

    }

};


class ColorDescriptor : public cFeatures
{
public:
    int repeat;
    ColorDescriptor()
    {
        detector  = cv::Ptr<cv::FeatureDetector>((new cv::DenseFeatureDetector));
        repeat=8;

    }

    void calculateKeypoints(const cv::Mat &img)
    {
        this->keypoints.clear();
        detector->detect(img, this->keypoints);
    }

    void calculateDescriptors(const cv::Mat &img, const cv::Mat &segments)
    {
        this->descriptors.create(this->keypoints.size(), 3*repeat, CV_32F);
        cv::Mat hsvImage;
        cv::cvtColor(img, hsvImage, cv::COLOR_BGR2HSV);

        for(int i=0;i<this->keypoints.size();i++)
        {
            cv::Vec3b pixel_color = img.at<cv::Vec3b>(keypoints[i].pt);
            for(int j=0;j<repeat;j++)
            {
                this->descriptors.at<float>(i ,0+3*j)=(float)pixel_color.val[0]/180;
                this->descriptors.at<float>(i ,1+3*j)=(float)pixel_color.val[1]/255;
                this->descriptors.at<float>(i ,2+3*j)=(float)pixel_color.val[2]/255;
            }
        }

        this->length = this->descriptors.cols;

    }
};

class LocationDescriptor : public cFeatures
{

public:
    int repeat;
    LocationDescriptor()
    {
        detector  = cv::Ptr<cv::FeatureDetector>((new cv::DenseFeatureDetector));
        repeat=12;
    }

    void calculateKeypoints(const cv::Mat &img)
    {
        this->keypoints.clear();
        detector->detect(img, this->keypoints);
    }

    void calculateDescriptors(const cv::Mat &img, const cv::Mat &segments)
    {
        this->descriptors.create(this->keypoints.size(), 2*repeat, CV_32F);
        cv::Mat hsvImage;
        cv::cvtColor(img, hsvImage, cv::COLOR_BGR2HSV);

        for(int i=0;i<this->keypoints.size();i++)
        {
            for(int j=0;j<repeat;j++)
            {
                this->descriptors.at<float>(i ,0+2*j)=(float)(this->keypoints[i].pt.x)/((float)img.cols);
                this->descriptors.at<float>(i ,1+2*j)=(float)(this->keypoints[i].pt.y)/((float)img.rows);
            }

        }

        this->length = this->descriptors.cols;

    }
};

class LBPDescriptor : public cFeatures
{
    public:
    int repeat;
    LBPDescriptor()
    {

    }

    void calculateKeypoints(const cv::Mat &img)
    {
        
    }

    cv::Mat feature_lbp(cv::Mat &img)
    {
        cv::Mat lbp;

        int radius = 1;
        int neighbors = 8;
        cv::Mat dst;

        cvtColor(img, dst, cv::COLOR_BGR2GRAY);
        dst.convertTo(dst, CV_32SC1); //Converting to <int>

        lbp::ELBP(dst, lbp, radius, neighbors);
        normalize(lbp, lbp, 0, 255, NORM_MINMAX, CV_8UC1);


        //std::cout<<std::endl<<lbp;
        return lbp.clone();
    }

    cv::Mat feature_lbp_grid(const cv::Mat &lbp_image)
    {
        cv::Mat descriptor;
        int dx[9] = {0, -1, -1, 0, 1, 1, 1, 0, -1 };
        int dy[9] = {0, 0, -1, -1, -1, 0, 1, 1, 1 };

        cv::Mat lbp;
        lbp_image.convertTo(lbp, CV_32F);

        for(int r = 0;r<lbp.rows; r++)
            for(int c=0;c<lbp.cols;c++)
            {
                int p=0;
                std::vector<float> values;
                cv::Mat desc = cv::Mat::zeros(1,255,CV_32F);
                //Iterate through GRID
                for (int i =0 ;i< 9;i++)
                {
                    if(withinRange(c+dx[i], r+dy[i], lbp) && lbp.at<float>(c+dx[i],r+dy[i])< 256)
                        values.push_back(lbp.at<float>(c+dx[i],r+dy[i]));

                }

                //Iterate through Vector
                for(int i=0;i<values.size();i++)
                {

                    int v = values[i];
                    desc.at<float>(0,v) +=1;
                }

                if(descriptor.empty())
                    descriptor=desc.clone();
                else
                    descriptor.push_back(desc);

            }
        return descriptor.clone();

    }




    void calculateDescriptors(const cv::Mat &img, const cv::Mat &segments)
    {
        

    }

}


class TextonDescriptor: public cFeatures
{
public:
    TextonDescriptor()
    {

    }
    ~TextonDescriptor()
    {

    }

    void loadDescriptorsFromFile(std::string file)
    {

    }
};

}

#endif // CFEATURES_H
