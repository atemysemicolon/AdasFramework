#ifndef FEATUREMANAGER_H
#define FEATUREMANAGER_H
#include <memory>
#include <map>

#define OPENCV3 0

#if OPENCV3
#include <opencv2/features2d.hpp>
#else
#include <opencv2/features2d/features2d.hpp>
#endif

#include "../core/Pipeline/cvccore.h"
#include "cFeatures.h"

namespace cvc {

enum FeatureList{SIFT, SURF, TEXTON, COLOR, LOCATION};



class featureManager: public cPipeModule
{
public:
    std::vector<std::shared_ptr<cFeatures> > features_ptr;
    cv::Mat descriptors_concatenated;
    bool to_bow_descriptor;
    cv::Mat dictionary;
    cv::Ptr<cv::DescriptorMatcher> flannMatcher;

    bool regularize;

    std::vector<int> lengths;

    cv::Mat weights;
    cv::Mat bias;


    featureManager()
    {
        this->data_type=DataTypes::DATA_SINGLE;
        this->to_bow_descriptor = false;
        this->pipe_name="Feature Manager";
    }
    ~featureManager()
    {
        this->features_ptr.clear();
    }

    void setRegularizeOption(bool option)
    {
        this->regularize=option;
    }

    void initFeatures(std::vector<FeatureList> &features)
    {
        for(int i = 0;i<features.size();i++)
        {
            if(features[i]==FeatureList::SIFT)
                this->features_ptr.push_back(std::shared_ptr<cFeatures>(new SiftDescriptor));
            if(features[i]==FeatureList::COLOR)
                this->features_ptr.push_back(shared_ptr<cFeatures>(new ColorDescriptor));
            if(features[i]==FeatureList::LOCATION)
                this->features_ptr.push_back(shared_ptr<cFeatures>(new LocationDescriptor));
        }

        this->lengths.resize(features.size());

    }

    void setWeightsAndBias(cv::Mat &wtMat, cv::Mat &biasMat)
    {
        this->weights   =   wtMat.clone();
        this->bias      =   biasMat.clone();
    }

    void initBagOfWords(cv::Mat &dictionary)
    {
        dictionary.convertTo(this->dictionary, CV_32FC1);
        this->to_bow_descriptor = true;
        //flannMatcher(new cv::FlannBasedMatcher);
        flannMatcher=cv::Ptr<cv::DescriptorMatcher>(new cv::FlannBasedMatcher);
        std::cout<<"Dimensions of dictionary : "<<this->dictionary.rows<<","<<this->dictionary.cols<<std::endl;

        //flannMatcher->add(this->dictionary);
    }


    void generate_keypoint_map(cv::Mat &superpixels, std::multimap< int, cv::KeyPoint> &keypoint_map, std::multimap<int, int> &keypoint_row_map, int descriptor_number)
    {
        //Pairing keypoint to superpixel and keypoint row to superpixel
        int x = 0;


        for(int i=0;i < this->features_ptr[descriptor_number]->keypoints.size(); i++)
            {
                cv::KeyPoint kp = features_ptr[descriptor_number]->keypoints[i];
                cv::Point p;
                p.x=kp.pt.x;
                p.y = kp.pt.y;

                int segment_number = (int)superpixels.at<float>(p);
                keypoint_map.insert(std::pair<int, cv::KeyPoint>(segment_number,kp));
                keypoint_row_map.insert(std::pair<int, int>(segment_number,i));
            }
    }

    //Change Average to BOW on test
    cv::Mat calcSuperpixelDescriptor(std::multimap<int, int> &keypoint_row_map, cv::Mat &descriptors, int superpixel_number)
    {
        cv::Mat pooledDescriptor, tempDescriptor;
        std::pair<std::multimap<int, int>::iterator, std::multimap<int, int>::iterator> pr2;
        pr2 = keypoint_row_map.equal_range(superpixel_number);
        int count = 0;

        for(std::multimap<int, int>::iterator it = pr2.first; it!=pr2.second;++it)
        {
            count++;
           // std::cout<<(*it).first<<", "<<descriptors.row((*it).second)<<std::endl;
            if (tempDescriptor.empty())
                tempDescriptor = descriptors.row((*it).second).clone();
            else
                tempDescriptor.push_back(descriptors.row((*it).second));
        }
        // std::cout<<tempDescriptor<<std::endl; //-NonZeros

        if(!to_bow_descriptor)
        {
            pooledDescriptor = averageDescriptor(tempDescriptor).clone();
            if(pooledDescriptor.empty())
                pooledDescriptor=cv::Mat::zeros(1, descriptors.cols, descriptors.type());

        }
        else
            pooledDescriptor=tempDescriptor;
//        else
//        {
//            pooledDescriptor = normalToBowDescriptor(tempDescriptor);
//            if(pooledDescriptor.empty())
//                pooledDescriptor=cv::Mat::zeros(1, this->dictionary.rows, descriptors.type());
//        }
        //std::cout<<pooledDescriptor<<std::endl; //--All Zeros ->Mistake somewhere in BOW

        return pooledDescriptor;

    }

    static cv::Mat averageDescriptor(cv::Mat &descriptors)
    {
        cv::Mat tempDescriptor;

            for(int i = 0; i<descriptors.rows; i++)
            {
                if(tempDescriptor.empty())
                    tempDescriptor = descriptors.row(i).clone();
                else
                    tempDescriptor+=descriptors.row(i);
            }
            tempDescriptor = tempDescriptor/descriptors.rows;


        return tempDescriptor;
    }


    void regularizeDescriptor(cv::Mat &descriptors)
    {
        for(int i=0;i<descriptors.rows;i++)
        {

            cv::Mat temp = descriptors.row(i);
            temp = temp- this->bias;
            cv::divide(temp, this->weights, temp);

        }

    }

    cv::Mat normalToBowDescriptor(cv::Mat &descriptors)
    {
        cv::Mat codedDescriptor;
        //Opencv 3.0

//        cv::Ptr<cv::BOWImgDescriptorExtractor> bowExtractor(new cv::BOWImgDescriptorExtractor(flannMatcher));
//        bowExtractor->setVocabulary(this->dictionary);
//        bowExtractor->compute(descriptors, codedDescriptor);
        if(this->regularize)
            regularizeDescriptor(descriptors);
        this->computeBOW(descriptors, codedDescriptor, this->flannMatcher);

        if(!descriptors.empty())
            return codedDescriptor;
        else
            return cv::Mat::zeros(1,this->dictionary.rows, CV_32F);



    }

    void computeBOW( cv::InputArray keypointDescriptors, cv::OutputArray _imgDescriptor, cv::Ptr<cv::DescriptorMatcher> dmatcher)
    {
        CV_Assert( !this->dictionary.empty() );

        int clusterCount = this->dictionary.rows; // = vocabulary.rows
        //std::cout<<keypointDescriptors.getMat()<<std::endl; -Fixed

        // Match keypoint descriptors to cluster center (to vocabulary)
        std::vector<cv::DMatch> matches;
        dmatcher->match( keypointDescriptors.getMat(), this->dictionary, matches );
        //Beauty in adding dictionary to the matcher


        _imgDescriptor.create(1, clusterCount, CV_32FC1);
        //_imgDescriptor.setTo(Scalar::all(0));

        cv::Mat imgDescriptor = _imgDescriptor.getMat();
        imgDescriptor.setTo(cv::Scalar::all(0));

        float *dptr = imgDescriptor.ptr<float>();
        for( size_t i = 0; i < matches.size(); i++ )
        {
            int queryIdx = matches[i].queryIdx;
            int trainIdx = matches[i].trainIdx; // cluster index
            CV_Assert( queryIdx == (int)i );

            dptr[trainIdx] = dptr[trainIdx] + 1.f;
        }

        // Normalize image descriptor.
        imgDescriptor /= keypointDescriptors.size().height;
        //std::cout<<imgDescriptor<<std::endl; -Fixed

    }



    void calculateDescriptor(const cv::Mat &img, const cv::Mat &segments)
    {
        for(int i=0;i<this->features_ptr.size();i++)
        {
            this->features_ptr[i]->calculateKeypoints(img);
            this->features_ptr[i]->calculateDescriptors(img, segments);
            this->lengths[i]=(this->features_ptr[i]->length);
           // std::cout<<this->features_ptr[i]->descriptors<<std::endl; -> Gives non-zero values
        }

    }



    //fancy function doing stuff when superpixels are pooled.Where is original annotation? Get from superpixels
    cv::Mat poolDescriptors(cv::Mat &segmented_image, int descriptor_number)
    {
        double min;double max;
        cv::minMaxIdx(segmented_image, &min, &max);
        int number_superpixels = max+1;
        cv::Mat superpixels;
        segmented_image.convertTo(superpixels, CV_32F);

        cv::Mat superpixel_descriptors;

        //KeyPoint map generator
        std::multimap< int, cv::KeyPoint> keypoint_map;
        std::multimap<int, int> keypoint_row_map; //From superpixel to keypoint row(same as descriptor rows)


        generate_keypoint_map(superpixels, keypoint_map, keypoint_row_map, descriptor_number);

        for(int i=0;i<number_superpixels;i++)
        {

                //if(i==122)
                  //  std::cout<<"Oh shit";
                if(superpixel_descriptors.empty())
                        superpixel_descriptors= calcSuperpixelDescriptor(keypoint_row_map, features_ptr[descriptor_number]->descriptors,i).clone();
                else
                {
                    cv::Mat tempMat = calcSuperpixelDescriptor(keypoint_row_map, features_ptr[descriptor_number]->descriptors,i).clone();
                        superpixel_descriptors.push_back(tempMat);
                        //std::cout<<tempMat<<std::endl; --All Zeros
                //std::cout<<i<<"-"<<superpixel_descriptors.rows<<std::endl;
                }



        }

        return superpixel_descriptors;

    }

    //fancy function doing stuff when superpixels are pooled.Where is original annotation? Get from superpixels
    cv::Mat poolDescriptors(cv::Mat &segmented_image)
    {
        double min;double max;
        cv::minMaxIdx(segmented_image, &min, &max);
        int number_superpixels = max+1;
        cv::Mat superpixels;
        segmented_image.convertTo(superpixels, CV_32F);

        cv::Mat superpixel_descriptors;

        //KeyPoint map generator
        std::vector<std::multimap< int, cv::KeyPoint>> keypoint_map;
        std::vector<std::multimap<int, int>> keypoint_row_map; //From superpixel to keypoint row(same as descriptor rows)
        keypoint_map.resize(this->features_ptr.size());
        keypoint_row_map.resize(this->features_ptr.size());

        for(int descriptor_number = 0; descriptor_number<this->features_ptr.size();descriptor_number++)
        {
            generate_keypoint_map(superpixels, keypoint_map[descriptor_number], keypoint_row_map[descriptor_number], descriptor_number);
        }

        for(int i=0;i<number_superpixels;i++)
        {
            std::vector<cv::Mat> desc_diff;

            //Calculating Descriptor of a single Superpixel
            for(int j=0;j<this->features_ptr.size();j++)
                   desc_diff.push_back(calcSuperpixelDescriptor(keypoint_row_map[j], features_ptr[j]->descriptors,i).clone());
            cv::Mat temp;

            //Concatinating all descriptors
            for(int j=0;j<this->features_ptr.size();j++)
            {
                if(temp.empty())
                    temp=desc_diff[j];
                else
                    cv::hconcat(temp, desc_diff[j], temp);
            }
            if(superpixel_descriptors.empty())
                 superpixel_descriptors= normalToBowDescriptor(temp).clone();
            else
                superpixel_descriptors.push_back(normalToBowDescriptor(temp));
            temp.release();
            desc_diff.clear();

        }


        return superpixel_descriptors;

    }

    cv::Mat concatDescriptors()
    {
        for(int i=0;i<features_ptr.size();i++)
        {
            if(descriptors_concatenated.empty())
                descriptors_concatenated = features_ptr[i]->descriptors.clone();
            else
                cv::hconcat(descriptors_concatenated,features_ptr[i]->descriptors, descriptors_concatenated);
        }

        //std::cout<<"Dimensions of final desc are : "<<descriptors_concatenated.rows<<", "<<descriptors_concatenated.cols<<std::endl;

        return descriptors_concatenated;
    }



    void processData(std::shared_ptr<cData> data)
    {
        calculateDescriptor(data->image, data->superpixel_segments);
        if(!to_bow_descriptor)
        {
            for(int i=0;i<features_ptr.size();i++)
                features_ptr[i]->descriptors=poolDescriptors(data->superpixel_segments, i).clone(); //Loop over to get every feature
            concatDescriptors();
            data->descriptors_concat_pooled=this->descriptors_concatenated.clone();
            this->descriptors_concatenated.release();


        }
        else
           data->descriptors_concat_pooled=poolDescriptors(data->superpixel_segments).clone();

         std::cout<<"Dimensions of descriptors : "<<data->descriptors_concat_pooled.rows<<", "<<data->descriptors_concat_pooled.cols<<std::endl;

    }



};

class codifyFeatures : public cPipeModule
{
public:
    cv::Mat dictionary;
    cv::Mat descriptors_all;
    int clusterCount;
    bool isTrained;
    bool useContextDescriptors;
    std::string filename;
    std::string filename_weights;

    std::vector<int> feature_lengths;
    bool regularize;

    codifyFeatures()
    {
        isTrained = false;
        this->clusterCount = 100;
        this->pipe_name="Bag Of Words";
        this->data_type=DataTypes::DATA_SINGLE;
        useContextDescriptors=false;

    }

    void init(int clusters)
    {
        this->clusterCount=clusters;
    }

    void setDictionaryFilename(std::string filename_dictionary, std::string filename_weights)
    {
        this->filename=filename_dictionary;
        this->filename_weights = filename_weights;
    }

    void setDescriptorLengths(std::vector<int> lengths)
    {
        this->feature_lengths=lengths;
    }

    void setRegularizeOption(bool option)
    {
        this->regularize=option;
    }

    void setUseContextDescriptorsToo(bool option)
    {
        this->useContextDescriptors=option;
    }


    void aggregateDescriptors(cv::Mat &descriptors)
    {
        if(descriptors_all.empty())
            descriptors_all = descriptors.clone();
        else
            cv::vconcat(descriptors_all, descriptors, descriptors_all);
    }
    cv::Mat addContextDescriptors(const cv::Mat &descriptors, const cv::Mat &superpixel_nbrs)
    {
        cv::Mat descriptor_right;
        for(int number=0;number<descriptors.rows;number++)
        {
            cv::Mat nbrDescriptors;
            cv::Mat rowMat = superpixel_nbrs.row(number);
            //std::cout<<"Nbrs of superpixel : "<<number<<" are : ";
            int i=0;
            for(i=0;i<rowMat.cols;i++)
            {
                if(rowMat.at<int>(0,i)<0)
                    break;
                else
                {
                    //std::cout<<rowMat.at<int>(0,i)<<" ";
                    int nbrIdx = rowMat.at<int>(0,i);

                    if(nbrDescriptors.empty())
                        nbrDescriptors=descriptors.row(nbrIdx).clone();
                    else
                        nbrDescriptors.push_back(descriptors.row(nbrIdx).clone());

                }

            }
            if(i==0)
                nbrDescriptors=cv::Mat::zeros(1, descriptors.cols, CV_32FC1);

            cv::Mat tmp = cvc::featureManager::averageDescriptor(nbrDescriptors);
            if(descriptor_right.empty())
                descriptor_right=tmp.clone();
            else
                descriptor_right.push_back(tmp.clone());
        }
        cv::Mat fullonDescriptor;
        cv::hconcat(descriptors, descriptor_right, fullonDescriptor);

        return fullonDescriptor;
    }

    void clusterEmAll(cv::Mat &desc)
    {
        cv::Mat descriptors;
        desc.convertTo(descriptors, CV_32F);
        std::cout<<"\t\tClustering..."<<std::endl;
        //cv::TermCriteria tc(1,1,2);
            cv::Ptr<cv::BOWTrainer> bowObj;
            bowObj =  cv::Ptr<cv::BOWTrainer>(new cv::BOWKMeansTrainer(this->clusterCount));
            //bowObj.add(desc);
            this->dictionary =bowObj->cluster(descriptors).clone();
            isTrained = true;
            bowObj.release();
    }

    //This function will have to go to FeatureManager - Keep this class only to train clusters
//    cv::Mat normalToBowDescriptor(cv::Mat &descriptors)
//    {
//        cv::Mat codedDescriptor;
//        cv::Ptr<cv::DescriptorMatcher> flannMatcher = cv::DescriptorMatcher::create("FlannBased");
//        cv::Ptr<cv::BOWImgDescriptorExtractor> bowExtractor(new cv::BOWImgDescriptorExtractor(flannMatcher));
//        bowExtractor->setVocabulary(this->dictionary);
//        bowExtractor->compute(descriptors, codedDescriptor);
//        return codedDescriptor;
//    }

    void calculateWeights(cv::Mat &desc, cv::Mat &weights, cv::Mat &bias)
    {
        std::cout<<"\t\t Calculating weights---"<<std::endl;
        weights.create(1, desc.cols, CV_32F);
        bias.create(1, desc.cols, CV_32F);

        //Creating Weights for each feature set
        int start=0;
        int end;
        for(int i=0;i<this->feature_lengths.size();i++)
        {
            end = start+feature_lengths[i];
            cv::Mat colMat = desc.colRange(start, end);
            double min, max;
            cv::minMaxLoc(colMat, &min, &max);


            for(int j=start;j<end;j++)
            {
                weights.at<float>(0,j) = (std::abs(max-min)<1)?max:(float)(max-min);
                bias.at<float>(0, j) = (float)min;


            }

            start=end;
        }



    }


    cv::Mat regularizeSamples(const cv::Mat &desc, const cv::Mat &weights, const cv::Mat &bias)
    {
        std::cout<<"\t\tRegularizing..."<<std::endl;
        cv::Mat weightsMat;
        cv::Mat biasMat;

        cv::repeat(weights, desc.rows, 1, weightsMat);
        cv::repeat(bias, desc.rows, 1, biasMat);
        //Regularizing each row
        cv::Mat outDescriptor = (desc-biasMat)/weightsMat;



        return outDescriptor;

    }

    void processData(std::shared_ptr<cData> data)
    {
        if(data->mode==cvc::DatasetTypes::TEST)
            isTrained=true;

        if(!isTrained)
            this->aggregateDescriptors(data->descriptors_concat_pooled);
        else if(useContextDescriptors)
        {
            cv::Mat temp=this->addContextDescriptors(data->descriptors_concat_pooled, data->superpixel_neighbours).clone();
            data->descriptors_concat_pooled=temp.clone();
            temp.release();
        }

    }

    void writeDictionary(cv::Mat &dictionary, std::string filename)
    {
        cv::FileStorage fs;
        fs.open(filename, cv::FileStorage::WRITE);
        fs<<"Dictionary"<<dictionary;
        fs.release();
    }

    void readWeights(cv::Mat &weightsMat, cv::Mat &biasMat, std::string &filename)
    {
        cv::FileStorage fs;
        fs.open(filename, cv::FileStorage::READ);
        fs["Weights"]>>weightsMat;
        fs["Bias"]>>biasMat;
        fs.release();
    }
    void writeWeights(cv::Mat &weightsMat, cv::Mat &biasMat, std::string &filename)
    {
        cv::FileStorage fs;
        fs.open(filename, cv::FileStorage::WRITE);
        fs<<"Weights"<<weightsMat;
        fs<<"Bias"<<biasMat;
        fs.release();
    }

    void readDictionary(cv::Mat &dictionary, std::string filename)
    {
        cv::FileStorage fs;
        fs.open(filename, cv::FileStorage::READ);
        fs["Dictionary"]>>dictionary;
        fs.release();
        this->isTrained=true;
    }


    void finalOperations(std::shared_ptr<cData> data)
    {
        std::cout<<"Final Operations at Bag of Words:-"<<std::endl;
        if(!isTrained)
        {
            if(regularize)
            {
                this->calculateWeights(this->descriptors_all,data->featureWeights, data->featureBias);
                cv::Mat regularized = this->regularizeSamples(this->descriptors_all, data->featureWeights, data->featureBias).clone();
                this->clusterEmAll(regularized);//(this->descriptors_all);//
            }
            else
                this->clusterEmAll(this->descriptors_all);

            data->dictionary = this->dictionary.clone();
            this->writeDictionary(this->dictionary, this->filename);
            this->writeWeights(data->featureWeights, data->featureBias, this->filename_weights);
            isTrained=true;
            this->descriptors_all.release();

        }

    }

};

}

#endif // FEATUREMANAGER_H
